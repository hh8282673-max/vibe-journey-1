# Vibe Journey - Phase 1 (runs, plays demo audio)

1. flutter create vibe_journey
2. cd vibe_journey
3. Delete test/widget_test.dart and the default lib/main.dart
4. Copy this zip's lib/ folder and pubspec.yaml into the project (overwrite)
5. Open android/app/src/main/AndroidManifest.xml and add, just above <application ...>:
       <uses-permission android:name="android.permission.INTERNET"/>
6. flutter pub get
7. Connect phone via USB (USB debugging ON), then: flutter run
