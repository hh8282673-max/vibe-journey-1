import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/demo_songs.dart';
import '../providers.dart';
import '../theme.dart';
import '../widgets.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Widget _label(BuildContext c, String t) => Padding(
        padding: const EdgeInsets.only(top: 22, bottom: 10),
        child: Text(t,
            style: Theme.of(c)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w700)),
      );

  Widget _chips(WidgetRef ref, String? filter, List<String> items) => Wrap(
        spacing: 8,
        runSpacing: 4,
        children: items
            .map((m) => ChoiceChip(
                  label: Text(m),
                  selected: filter == m,
                  onSelected: (v) =>
                      ref.read(filterProvider.notifier).state = v ? m : null,
                ))
            .toList(),
      );

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final filter = ref.watch(filterProvider);
    final recent = ref.watch(recentProvider);
    final songs = demoSongs
        .where((s) => filter == null || s.mood == filter || s.era == filter)
        .toList();
    final hour = DateTime.now().hour;
    final greet = hour < 12
        ? 'Good morning'
        : hour < 17
            ? 'Good afternoon'
            : 'Good evening';

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        children: [
          Text(greet,
              style: Theme.of(context)
                  .textTheme
                  .headlineSmall
                  ?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text("What's your vibe today?", style: TextStyle(color: VC.muted)),
          _label(context, 'Mood'),
          _chips(ref, filter, moods),
          _label(context, 'Era'),
          _chips(ref, filter, eras),
          if (recent.isNotEmpty) ...[
            _label(context, 'Recently played'),
            SizedBox(
              height: 130,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: recent.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (_, i) => GestureDetector(
                  onTap: () => ref
                      .read(playerProvider.notifier)
                      .play(recent[i], queue: recent),
                  child: SizedBox(
                    width: 96,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Cover(song: recent[i], size: 96),
                        const SizedBox(height: 6),
                        Text(recent[i].title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
          _label(context, filter ?? 'Recommended'),
          if (songs.isEmpty)
            const EmptyState(
              icon: Icons.music_off_rounded,
              title: 'Nothing here yet',
              subtitle: 'No songs match this mood or era. Try another one.',
            )
          else
            ...songs.map((s) => SongTile(song: s, queue: songs)),
        ],
      ),
    );
  }
}
